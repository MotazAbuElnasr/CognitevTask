module.exports={
    secret:"Cognitev_secret"
}